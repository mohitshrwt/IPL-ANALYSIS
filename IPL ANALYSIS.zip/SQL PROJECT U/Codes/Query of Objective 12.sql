use ipl;
---Win Percentage of Each Team--
SELECT 
    team.Team_Name,
    COUNT(CASE WHEN matches.Match_Winner = team.Team_Id THEN 1 END) * 100.0 / COUNT(matches.Match_Id) AS Win_Percentage
FROM 
    team
LEFT JOIN 
    matches ON matches.Team_1 = team.Team_Id 
GROUP BY 
    team.Team_Name;

---Number of Catches Taken by Each Player---
SELECT 
    player.Player_Name,
    COUNT(*) AS Catches_Taken
FROM 
    wicket_taken
INNER JOIN 
    player ON wicket_taken.Fielders = player.Player_Id
WHERE 
    wicket_taken.Kind_Out = (SELECT Out_Id FROM out_type WHERE Out_Name = 'Caught')
GROUP BY 
    player.Player_Name;
---Total Runs Conceded by Each Player---
SELECT 
    player.Player_Name,
    SUM(batsman_scored.Runs_Scored) + IFNULL(SUM(extra_runs.Extra_Runs), 0) AS Total_Runs_Conceded
FROM 
    ball_by_ball
INNER JOIN 
    player ON ball_by_ball.Bowler = player.Player_Id
LEFT JOIN 
    batsman_scored ON ball_by_ball.Match_Id = batsman_scored.Match_Id AND 
                     ball_by_ball.Over_Id = batsman_scored.Over_Id AND 
                     ball_by_ball.Ball_Id = batsman_scored.Ball_Id AND 
                     ball_by_ball.Innings_No = batsman_scored.Innings_No
LEFT JOIN 
    extra_Runs ON ball_by_ball.Match_Id = extra_runs.Match_Id AND 
                  ball_by_ball.Over_Id = extra_runs.Over_Id AND 
                  ball_by_ball.Ball_Id = extra_runs.Ball_Id AND 
                  ball_by_ball.Innings_No = extra_runs.Innings_No
GROUP BY 
    player.Player_Name;
---Total Wickets Taken by Each Player---
SELECT 
    player.Player_Name,
    COUNT(*) AS Total_Wickets
FROM 
    wicket_taken
INNER JOIN 
    player ON wicket_taken.Kind_Out = player.Player_Id
WHERE 
    wicket_taken.Kind_Out IN (SELECT Out_Id FROM out_type WHERE Out_Name IN ('Bowled', 'Caught', 'LBW', 'Stumped', 'Caught & Bowled', 'Hit Wicket'))
GROUP BY 
    player.Player_Name;
---Bowling Average---
SELECT 
    player.Player_Name,
    SUM(batsman_scored.Runs_Scored + IFNULL(extra_runs.Extra_Runs, 0)) / COUNT(*) AS Bowling_Average
FROM 
    ball_by_ball
INNER JOIN 
    player ON ball_by_ball.Bowler = player.Player_Id
LEFT JOIN 
    batsman_scored ON ball_by_ball.Match_Id = batsman_scored.Match_Id AND 
                     ball_by_ball.Over_Id = batsman_scored.Over_Id AND 
                     ball_by_ball.Ball_Id = batsman_scored.Ball_Id AND 
                     ball_by_ball.Innings_No = batsman_scored.Innings_No
LEFT JOIN 
    extra_runs ON ball_by_ball.Match_Id = extra_runs.Match_Id AND 
                  ball_by_ball.Over_Id = extra_runs.Over_Id AND 
                  ball_by_ball.Ball_Id = extra_runs.Ball_Id AND 
                  ball_by_ball.Innings_No = extra_runs.Innings_No
INNER JOIN 
    wicket_taken ON ball_by_ball.Match_Id = wicket_taken.Match_Id AND 
                    ball_by_ball.Over_Id = wicket_taken.Over_Id AND 
                    ball_by_ball.Ball_Id = wicket_taken.Ball_Id AND 
                    ball_by_ball.Innings_No = wicket_taken.Innings_No
GROUP BY 
    player.Player_Name;
