-- top 5 score rank in each season--players and number of times they are in top 5 in last 3 seasons 
with player_match_runs as (select bb.match_id,bb.striker,sum(runs_scored) as total_runs
					      from ball_by_ball bb join batsman_scored bs on bb.Match_Id=bs.Match_Id and bb.Innings_No=bs.Innings_No
																and bb.Over_Id=bs.Over_Id and bb.Ball_Id=bs.Ball_Id 
							group by bb.match_id,bb.striker),
result as (select pmr.striker as player_id,s.season_year,
                                 sum(pmr.total_runs) runs_scored,
                                 dense_rank() over(partition by season_year order by sum(pmr.total_runs) desc) season_runs_rank
			from player_match_runs pmr join matches m on pmr.match_id=m.match_id
			join season s on m.season_id=s.season_id
			group by pmr.striker,s.season_year),
top_run_rank_player as (select * from result
						where season_runs_rank between 1 and 5
						and season_year between 2014 and 2016
		                order by season_year,season_runs_rank)
select trp.player_id,p.player_name,count(trp.player_id) as no_of_times_in_top5 
from top_run_rank_player trp join player p on trp.player_id=p.player_id
group by trp.player_id,p.player_name
order by count(trp.player_id) desc
limit 10; 